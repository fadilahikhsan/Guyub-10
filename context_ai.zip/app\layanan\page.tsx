"use client";

import { useState } from "react";
import Link from "next/link";
import { ChevronRight, FileText, CheckCircle2, ArrowRight, ArrowLeft } from "lucide-react";
import { submitSurat } from "./actions";

export default function LayananSuratPage() {
  const [step, setStep] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setErrorMessage("");

    if (step < 3) {
      setStep(step + 1);
      return;
    }

    setIsSubmitting(true);
    
    // Kirim data ke Server Action
    const formData = new FormData(e.currentTarget);
    const result = await submitSurat(formData);

    if (result.error) {
      setErrorMessage(result.error);
      setIsSubmitting(false);
    } else {
      setIsSuccess(true);
    }
  };

  if (isSuccess) {
    return (
      <div className="flex flex-col min-h-[70vh] items-center justify-center p-4 bg-background">
        <div className="bg-white p-12 rounded-2xl border border-border max-w-lg w-full text-center shadow-lg">
          <CheckCircle2 className="w-24 h-24 text-green-500 mx-auto mb-6" />
          <h1 className="text-3xl font-black tracking-tight mb-4" style={{ fontFamily: "var(--font-bitter)" }}>Pengajuan Berhasil!</h1>
          <p className="text-lg text-muted-foreground font-medium mb-8">
            Permintaan surat pengantar Anda telah masuk ke sistem. Ketua RT/RW akan memprosesnya dan Anda akan menerima notifikasi jika disetujui.
          </p>
          <Link href="/">
            <button className="bg-primary text-white font-bold px-8 py-4 rounded-xl hover:bg-blue-700 transition-all w-full">
              Kembali ke Beranda
            </button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col min-h-screen pt-12 pb-20 bg-background">
      <section className="container mx-auto px-4 max-w-3xl mb-8">
        <div className="flex items-center text-sm font-bold text-muted-foreground mb-6">
          <Link href="/" className="hover:text-primary transition-colors">Beranda</Link>
          <ChevronRight className="h-4 w-4 mx-2" />
          <span className="text-foreground">Layanan Surat</span>
        </div>
        
        <h1 className="text-4xl md:text-5xl font-black tracking-tight mb-4 flex items-center text-foreground" style={{ fontFamily: "var(--font-bitter)" }}>
          <FileText className="mr-4 text-primary w-10 h-10 md:w-12 md:h-12" />
          Pengajuan Surat
        </h1>
        <p className="text-lg text-muted-foreground font-medium">
          Isi formulir pengajuan di bawah ini. Pastikan Anda telah masuk (login) agar data pengajuan tersimpan dengan benar.
        </p>
      </section>

      <section className="container mx-auto px-4 max-w-3xl">
        <div className="bg-white rounded-2xl p-6 md:p-10 border border-border shadow-md">
          
          {/* Progress Bar */}
          <div className="mb-10">
            <div className="flex justify-between mb-2">
              <span className={`text-xs font-bold ${step >= 1 ? 'text-primary' : 'text-muted-foreground'}`}>Jenis</span>
              <span className={`text-xs font-bold ${step >= 2 ? 'text-primary' : 'text-muted-foreground'}`}>Identitas</span>
              <span className={`text-xs font-bold ${step >= 3 ? 'text-primary' : 'text-muted-foreground'}`}>Selesai</span>
            </div>
            <div className="h-2 w-full bg-gray-100 rounded-full overflow-hidden">
              <div 
                className="h-full bg-primary transition-all duration-500 ease-in-out"
                style={{ width: `${(step / 3) * 100}%` }}
              ></div>
            </div>
          </div>

          {errorMessage && (
            <div className="mb-6 p-4 rounded-xl bg-red-50 border-2 border-red-200 text-red-600 text-sm font-bold text-center">
              {errorMessage}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-8">
            
            {step === 1 && (
              <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4">
                <h3 className="text-2xl font-bold mb-4" style={{ fontFamily: "var(--font-bitter)" }}>Pilih Jenis Surat</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <label className="cursor-pointer">
                    <input type="radio" name="jenis" value="Surat Domisili" className="peer sr-only" required />
                    <div className="bg-gray-50 border-2 border-gray-200 p-4 rounded-xl peer-checked:border-primary peer-checked:bg-blue-50 transition-all text-center font-bold text-foreground">
                      Surat Domisili
                    </div>
                  </label>
                  <label className="cursor-pointer">
                    <input type="radio" name="jenis" value="Keterangan Usaha" className="peer sr-only" required />
                    <div className="bg-gray-50 border-2 border-gray-200 p-4 rounded-xl peer-checked:border-primary peer-checked:bg-blue-50 transition-all text-center font-bold text-foreground">
                      Keterangan Usaha
                    </div>
                  </label>
                  <label className="cursor-pointer">
                    <input type="radio" name="jenis" value="Pengantar Nikah" className="peer sr-only" required />
                    <div className="bg-gray-50 border-2 border-gray-200 p-4 rounded-xl peer-checked:border-primary peer-checked:bg-blue-50 transition-all text-center font-bold text-foreground">
                      Pengantar Nikah
                    </div>
                  </label>
                  <label className="cursor-pointer">
                    <input type="radio" name="jenis" value="Lainnya" className="peer sr-only" required />
                    <div className="bg-gray-50 border-2 border-gray-200 p-4 rounded-xl peer-checked:border-primary peer-checked:bg-blue-50 transition-all text-center font-bold text-foreground">
                      Lainnya
                    </div>
                  </label>
                </div>
              </div>
            )}

            {step === 2 && (
              <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4">
                <h3 className="text-2xl font-bold mb-4" style={{ fontFamily: "var(--font-bitter)" }}>Verifikasi Identitas</h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-bold text-muted-foreground mb-2">Nama Lengkap (Sesuai KTP)</label>
                    <input 
                      type="text" 
                      required
                      placeholder="Contoh: Budi Santoso"
                      className="w-full px-4 py-3 rounded-xl border border-gray-300 bg-white focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-all font-medium text-foreground"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-muted-foreground mb-2">Nomor Induk Kependudukan (NIK)</label>
                    <input 
                      type="text" 
                      required
                      pattern="\d{16}"
                      placeholder="16 Digit Angka"
                      className="w-full px-4 py-3 rounded-xl border border-gray-300 bg-white focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-all font-medium text-foreground"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-muted-foreground mb-2">Unggah Dokumen (KTP/KK)</label>
                    <input 
                      type="file" 
                      name="lampiran"
                      required
                      accept="image/jpeg, image/png, application/pdf"
                      className="w-full px-4 py-3 rounded-xl border border-gray-300 bg-white focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-all font-medium text-foreground file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
                    />
                  </div>
                  <p className="text-xs text-gray-500 italic mt-2">
                    Catatan: NIK dan Nama di atas sebagai verifikasi tambahan. Sistem secara otomatis menggunakan data dari akun Anda. Lampiran diperlukan untuk proses verifikasi.
                  </p>
                </div>
              </div>
            )}

            {step === 3 && (
              <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4">
                <h3 className="text-2xl font-bold mb-4" style={{ fontFamily: "var(--font-bitter)" }}>Detail Keperluan</h3>
                <div>
                  <label className="block text-sm font-bold text-muted-foreground mb-2">Mengapa Anda membutuhkan surat ini?</label>
                  <textarea 
                    name="keperluan"
                    required
                    rows={5}
                    placeholder="Jelaskan secara singkat. Contoh: Syarat pembuatan SKCK untuk melamar pekerjaan..."
                    className="w-full px-4 py-3 rounded-xl border border-gray-300 bg-white focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-all font-medium resize-none text-foreground"
                  ></textarea>
                </div>
              </div>
            )}

            <div className="pt-8 border-t border-gray-200 flex justify-between">
              {step > 1 ? (
                <button 
                  type="button" 
                  onClick={() => setStep(step - 1)}
                  className="flex items-center px-6 py-3 rounded-xl font-bold text-muted-foreground hover:text-foreground hover:bg-gray-100 transition-all"
                >
                  <ArrowLeft className="w-5 h-5 mr-2" /> Kembali
                </button>
              ) : (
                <div></div>
              )}
              
              <button 
                type="submit" 
                disabled={isSubmitting}
                className="flex items-center bg-primary text-white font-bold px-8 py-3 rounded-xl shadow-sm hover:bg-blue-700 hover:shadow-md transition-all disabled:opacity-50"
              >
                {isSubmitting ? (
                  <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2"></span>
                ) : null}
                {step === 3 ? "Kirim Pengajuan" : "Lanjut"}
                {step !== 3 && !isSubmitting && <ArrowRight className="w-5 h-5 ml-2" />}
              </button>
            </div>

          </form>
        </div>
      </section>
    </div>
  );
}
