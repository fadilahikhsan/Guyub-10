import Link from "next/link";
import { ChevronRight, Megaphone, Calendar } from "lucide-react";
import { createClient } from "@/lib/supabase/server";

export default async function InformasiPage() {
  const supabase = await createClient();
  const { data: pengumumanList } = await supabase
    .from("pengumuman")
    .select("*")
    .order("created_at", { ascending: false });

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('id-ID', {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    });
  };

  return (
    <div className="flex flex-col min-h-screen pt-24 pb-20">
      <section className="container mx-auto px-4 max-w-4xl mb-12">
        <div className="flex items-center text-sm font-bold text-muted-foreground mb-6">
          <Link href="/" className="hover:text-primary transition-colors">Beranda</Link>
          <ChevronRight className="h-4 w-4 mx-2" />
          <span className="text-foreground">Informasi Warga</span>
        </div>
        
        <h1 className="text-4xl md:text-5xl font-black tracking-tight mb-4 flex items-center text-glow">
          <Megaphone className="mr-4 w-12 h-12 text-primary" />
          Papan Pengumuman
        </h1>
        <p className="text-lg text-muted-foreground font-medium">
          Kabar terbaru, jadwal kegiatan, dan transparansi laporan keuangan lingkungan RW 10.
        </p>
      </section>

      <section className="container mx-auto px-4 max-w-4xl">
        <div className="flex flex-col gap-6">
          
          {pengumumanList && pengumumanList.length > 0 ? (
            pengumumanList.map((item) => {
              const isPenting = item.kategori.toLowerCase() === "penting" || item.kategori.toLowerCase() === "darurat";
              const accentColor = isPenting ? "destructive" : "accent";
              
              return (
                <article key={item.id} className="glass glass-hover rounded-3xl p-6 md:p-8 flex flex-col md:flex-row gap-6 relative overflow-hidden group">
                  <div className={`absolute top-0 right-0 w-32 h-32 bg-${accentColor}/10 blur-[50px] -z-10 group-hover:bg-${accentColor}/20 transition-colors`}></div>
                  
                  <div className="flex-1">
                    <div className="flex flex-wrap items-center gap-3 mb-4">
                      <span className={`bg-${accentColor}/20 text-${accentColor} border border-${accentColor}/30 font-bold px-3 py-1 rounded-full text-xs uppercase`}>
                        {item.kategori}
                      </span>
                      <div className="flex items-center text-muted-foreground font-medium text-xs">
                        <Calendar className="w-4 h-4 mr-2" /> {formatDate(item.created_at)}
                      </div>
                    </div>
                    <h2 className="text-2xl md:text-3xl font-bold mb-4 group-hover:text-primary transition-colors">
                      {item.judul}
                    </h2>
                    <p className="text-muted-foreground font-medium mb-6 line-clamp-3">
                      {item.konten}
                    </p>
                    <button className="text-primary font-bold flex items-center hover:underline text-sm uppercase tracking-wider">
                      Baca selengkapnya <ChevronRight className="w-4 h-4 ml-1" />
                    </button>
                  </div>
                </article>
              );
            })
          ) : (
            <div className="text-center py-12 text-muted-foreground font-medium">
              Belum ada pengumuman saat ini.
            </div>
          )}

        </div>
        
        {pengumumanList && pengumumanList.length > 0 && (
          <div className="mt-12 text-center">
            <button className="glass glass-hover text-foreground font-bold px-8 py-4 rounded-2xl transition-all">
              Muat Pengumuman Terdahulu
            </button>
          </div>
        )}
      </section>
    </div>
  );
}

