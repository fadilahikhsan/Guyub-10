"use client";

import { useState, useTransition } from "react";
import { Store, Check, X, Trash2, Loader2, MapPin } from "lucide-react";
import { updateUmkmStatus, deleteUmkm } from "./actions";

export function UmkmManager({ umkmList }: { umkmList: any[] }) {
  const [isPending, startTransition] = useTransition();

  const handleStatusUpdate = async (id: string, is_approved: boolean) => {
    startTransition(async () => {
      await updateUmkmStatus(id, is_approved);
    });
  };

  const handleDelete = async (id: string) => {
    if (confirm("Apakah Anda yakin ingin menghapus UMKM ini?")) {
      startTransition(async () => {
        await deleteUmkm(id);
      });
    }
  };

  return (
    <div className="bg-white p-6 md:p-8 rounded-3xl border-2 border-zinc-200 shadow-sm">
      <div className="flex items-center gap-2 mb-6">
        <Store className="w-5 h-5 text-emerald-500" />
        <h3 className="text-xl font-black text-zinc-800">Verifikasi UMKM Warga</h3>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse min-w-[800px]">
          <thead>
            <tr className="border-b-2 border-zinc-100 text-sm font-bold text-zinc-400">
              <th className="pb-3 w-1/4">Usaha & Kategori</th>
              <th className="pb-3 w-1/4">Pemilik (RT)</th>
              <th className="pb-3 w-1/4">Kontak & Deskripsi</th>
              <th className="pb-3 w-1/4">Status & Aksi</th>
            </tr>
          </thead>
          <tbody className="text-sm font-medium">
            {umkmList.map((u: any) => (
              <tr key={u.id} className="border-b border-zinc-50 hover:bg-zinc-50 transition-colors">
                <td className="py-4 pr-4">
                  <div className="font-bold text-zinc-800 text-base">{u.nama_usaha}</div>
                  <div className="text-xs font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-md inline-block mt-1">
                    {u.kategori}
                  </div>
                </td>
                <td className="py-4 pr-4 text-zinc-600">
                  <div className="font-bold text-zinc-800">{u.profiles?.nama_lengkap}</div>
                  <div className="flex items-center gap-1 text-xs text-zinc-500 mt-0.5">
                    <MapPin className="w-3 h-3" /> RT {u.profiles?.rt}
                  </div>
                </td>
                <td className="py-4 pr-4">
                  <div className="text-zinc-600 text-xs mb-1 line-clamp-2">{u.deskripsi}</div>
                  <div className="font-bold text-emerald-600 text-xs">WA: {u.nomor_wa}</div>
                </td>
                <td className="py-4">
                  {u.is_approved ? (
                    <div className="flex items-center gap-2">
                      <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-700 w-fit">
                        <Check className="w-3.5 h-3.5" /> Disetujui
                      </span>
                      <button
                        onClick={() => handleStatusUpdate(u.id, false)}
                        disabled={isPending}
                        className="p-2 bg-amber-50 text-amber-600 rounded-xl hover:bg-amber-100 transition-colors disabled:opacity-50"
                        title="Cabut Izin"
                      >
                        <X className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDelete(u.id)}
                        disabled={isPending}
                        className="p-2 bg-red-50 text-red-600 rounded-xl hover:bg-red-100 transition-colors disabled:opacity-50"
                        title="Hapus Permanen"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ) : (
                    <div className="flex items-center gap-2">
                      <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-amber-100 text-amber-700 w-fit">
                        Pending
                      </span>
                      <button
                        onClick={() => handleStatusUpdate(u.id, true)}
                        disabled={isPending}
                        className="p-2 bg-emerald-50 text-emerald-600 rounded-xl hover:bg-emerald-100 transition-colors disabled:opacity-50"
                        title="Setujui"
                      >
                        <Check className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDelete(u.id)}
                        disabled={isPending}
                        className="p-2 bg-red-50 text-red-600 rounded-xl hover:bg-red-100 transition-colors disabled:opacity-50"
                        title="Tolak / Hapus"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  )}
                </td>
              </tr>
            ))}
            {umkmList.length === 0 && (
              <tr>
                <td colSpan={4} className="py-8 text-center text-zinc-500">
                  Tidak ada pendaftaran UMKM saat ini.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
