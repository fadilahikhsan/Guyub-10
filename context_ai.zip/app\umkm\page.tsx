import Link from "next/link";
import { Search, ShoppingBag, Wrench, Briefcase, ChevronRight, MapPin, Store } from "lucide-react";
import { createClient } from "@/lib/supabase/server";

export default async function UMKMPage() {
  const supabase = await createClient();
  const { data: umkmList } = await supabase
    .from("umkm")
    .select(`
      *,
      profiles ( rt )
    `)
    .eq("is_approved", true)
    .order("created_at", { ascending: false });

  return (
    <div className="flex flex-col min-h-screen pt-24 pb-20">
      {/* Header Section */}
      <section className="container mx-auto px-4 max-w-6xl mb-12">
        <div className="flex items-center text-sm font-bold text-muted-foreground mb-6">
          <Link href="/" className="hover:text-primary transition-colors">Beranda</Link>
          <ChevronRight className="h-4 w-4 mx-2" />
          <span className="text-foreground">UMKM & Jasa Warga</span>
        </div>
        
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-8">
          <div className="max-w-2xl">
            <h1 className="text-4xl md:text-6xl font-black tracking-tight mb-4 text-glow">Pusat Ekonomi <br/><span className="text-primary">Warga RW 10</span></h1>
            <p className="text-lg text-muted-foreground font-medium">
              Dukung tetangga kita! Temukan produk makanan, jasa perbaikan, dan keahlian warga asli secara langsung.
            </p>
          </div>

          <div className="relative w-full md:w-[400px]">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
            <input 
              type="text" 
              placeholder="Cari nasi uduk, tukang AC..." 
              className="w-full pl-12 pr-4 py-4 rounded-2xl border border-white/10 bg-white/5 backdrop-blur-md text-foreground focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-all font-medium"
            />
          </div>
        </div>
      </section>

      {/* Categories (Capsule Pills) */}
      <section className="container mx-auto px-4 max-w-6xl mb-12">
        <div className="flex overflow-x-auto pb-4 gap-3 hide-scrollbar">
          <button className="flex items-center flex-shrink-0 px-6 py-2.5 rounded-full bg-primary text-primary-foreground font-bold shadow-[0_0_15px_rgba(0,242,254,0.3)]">
            Semua Kategori
          </button>
          <button className="flex items-center flex-shrink-0 px-6 py-2.5 rounded-full border border-white/10 bg-white/5 hover:bg-white/10 font-bold transition-all text-muted-foreground hover:text-foreground">
            <ShoppingBag className="w-4 h-4 mr-2" /> Makanan & Minuman
          </button>
          <button className="flex items-center flex-shrink-0 px-6 py-2.5 rounded-full border border-white/10 bg-white/5 hover:bg-white/10 font-bold transition-all text-muted-foreground hover:text-foreground">
            <Wrench className="w-4 h-4 mr-2" /> Jasa & Perbaikan
          </button>
          <button className="flex items-center flex-shrink-0 px-6 py-2.5 rounded-full border border-white/10 bg-white/5 hover:bg-white/10 font-bold transition-all text-muted-foreground hover:text-foreground">
            <Briefcase className="w-4 h-4 mr-2" /> Toko Kelontong
          </button>
        </div>
      </section>

      {/* UMKM List (Masonry-like Grid) */}
      <section className="container mx-auto px-4 max-w-6xl">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          
          {umkmList && umkmList.length > 0 ? (
            umkmList.map((umkm) => {
              const bgClass = umkm.kategori.toLowerCase() === "makanan" || umkm.kategori.toLowerCase().includes("makanan")
                ? "from-orange-500/40 to-red-500/40"
                : umkm.kategori.toLowerCase() === "jasa" || umkm.kategori.toLowerCase().includes("jasa")
                ? "from-blue-500/40 to-cyan-500/40"
                : "from-emerald-500/40 to-teal-500/40";
                
              const rt = umkm.profiles?.rt || "00";

              return (
                <div key={umkm.id} className="glass glass-hover rounded-3xl overflow-hidden flex flex-col group h-full">
                  <div className="h-48 bg-zinc-800 relative overflow-hidden">
                    <div className={`absolute inset-0 bg-gradient-to-br ${bgClass} group-hover:scale-110 transition-transform duration-700`}></div>
                    <div className="absolute inset-0 flex items-center justify-center opacity-20">
                      <Store className="w-24 h-24 text-white" />
                    </div>
                    <div className="absolute top-4 left-4 bg-black/60 backdrop-blur-md px-3 py-1.5 rounded-xl flex items-center gap-2 border border-white/10">
                      <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
                      <span className="text-xs font-bold text-white capitalize">{umkm.kategori}</span>
                    </div>
                  </div>
                  <div className="p-6 flex-1 flex flex-col">
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="text-2xl font-bold">{umkm.nama_usaha}</h3>
                    </div>
                    <p className="text-sm font-medium text-muted-foreground flex items-center gap-1 mb-4">
                      <MapPin className="w-4 h-4" /> RT {rt}
                    </p>
                    <p className="text-muted-foreground font-medium mb-6 flex-1">
                      {umkm.deskripsi}
                    </p>
                    <a 
                      href={`https://wa.me/${umkm.nomor_wa.replace(/[^0-9]/g, '')}`} 
                      target="_blank" 
                      rel="noreferrer"
                      className="flex items-center justify-center w-full rounded-2xl bg-[#25D366]/20 text-[#25D366] border border-[#25D366]/30 py-3 font-bold hover:bg-[#25D366]/30 transition-colors shadow-[0_0_15px_rgba(37,211,102,0.1)] hover:shadow-[0_0_20px_rgba(37,211,102,0.3)]"
                    >
                      Hubungi via WhatsApp
                    </a>
                  </div>
                </div>
              );
            })
          ) : (
            <div className="col-span-full text-center py-12 text-muted-foreground font-medium">
              Belum ada UMKM yang terdaftar.
            </div>
          )}

        </div>

        {/* CTA Promosikan Usaha (Premium Box) */}
        <div className="mt-20 relative overflow-hidden rounded-[2rem] p-8 md:p-12 flex flex-col md:flex-row items-center justify-between border border-primary/30 shadow-[0_0_40px_rgba(0,242,254,0.1)]">
          <div className="absolute inset-0 bg-gradient-to-r from-primary/20 to-accent/20 backdrop-blur-xl -z-10"></div>
          
          <div className="max-w-xl mb-8 md:mb-0">
            <h2 className="text-3xl font-black mb-4 text-glow">Punya Usaha atau Keahlian?</h2>
            <p className="text-lg font-medium text-white/80">
              Daftarkan usaha Anda di Guyub secara gratis! Biar seluruh warga RW tahu dan jualan Anda makin laris.
            </p>
          </div>
          <button className="w-full md:w-auto bg-foreground text-background px-8 py-4 rounded-2xl font-black text-lg hover:scale-105 transition-transform shadow-xl">
            Daftarkan Usaha Saya
          </button>
        </div>
      </section>
    </div>
  );
}
