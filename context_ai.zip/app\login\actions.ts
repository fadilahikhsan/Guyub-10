"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

export async function login(formData: FormData) {
  // BYPASS SEMENTARA: Langsung redirect ke admin tanpa cek password
  redirect("/admin");
}

export async function signup(formData: FormData) {
  const supabase = await createClient();

  const email = formData.get("email") as string;
  const password = formData.get("password") as string;
  const nik = (formData.get("nik") as string).trim();
  const nama_lengkap = (formData.get("nama_lengkap") as string).trim();
  const rt = (formData.get("rt") as string).trim();

  // --- Validasi input ---
  if (nik.length !== 16 || !/^\d+$/.test(nik)) {
    return { error: "NIK harus terdiri dari 16 digit angka." };
  }
  if (!nama_lengkap || nama_lengkap.length < 3) {
    return { error: "Nama lengkap minimal 3 karakter." };
  }
  if (!rt || !/^\d{1,3}$/.test(rt)) {
    return { error: "Nomor RT tidak valid." };
  }

  // --- 1. Daftarkan user ke Supabase Auth ---
  const { data: authData, error: authError } = await supabase.auth.signUp({
    email,
    password,
  });

  if (authError) {
    return { error: authError.message };
  }

  // --- 2. Simpan data profil warga ke tabel profiles ---
  // Catatan: authData.user bisa null jika email confirmation diaktifkan
  if (authData.user) {
    const { error: profileError } = await supabase.from("profiles").insert({
      id: authData.user.id,
      nik,
      nama_lengkap,
      rt: rt.padStart(3, "0"), // normalize: "1" → "001"
      rw: "01",
      role: "warga",
    });

    if (profileError) {
      // Rollback: hapus user auth jika profil gagal dibuat
      // (best effort — jika ini juga gagal, admin bisa hapus manual di Supabase dashboard)
      await supabase.auth.admin.deleteUser(authData.user.id).catch(() => null);
      return {
        error:
          profileError.code === "23505"
            ? "NIK sudah terdaftar. Gunakan NIK lain atau hubungi pengurus RW."
            : `Gagal menyimpan profil: ${profileError.message}`,
      };
    }
  }

  revalidatePath("/", "layout");
  redirect("/?registered=1");
}

export async function logout() {
  const supabase = await createClient();
  await supabase.auth.signOut();
  revalidatePath("/", "layout");
  redirect("/login");
}
