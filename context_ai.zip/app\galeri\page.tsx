import Link from "next/link";
import { ChevronRight, Camera } from "lucide-react";
import GalleryClient from "./GalleryClient";

export default function GaleriPage() {
  // Demo data for the gallery (can be connected to Supabase later)
  const dummyGallery = [
    { id: 1, url: "/demo1.jpg", title: "Kerja Bakti Bersih Desa", category: "Gotong Royong" },
    { id: 2, url: "/demo2.jpg", title: "Peringatan HUT RI ke-81", category: "Perayaan" },
    { id: 3, url: "/demo3.jpg", title: "Posyandu Balita Mawar", category: "Kesehatan" },
    { id: 4, url: "/demo4.jpg", title: "Bazar UMKM Warga 01", category: "Ekonomi" },
    { id: 5, url: "/demo5.jpg", title: "Rapat Pleno Pengurus RT", category: "Organisasi" },
    { id: 6, url: "/demo6.jpg", title: "Penyemprotan Disinfektan", category: "Kesehatan" },
  ];

  return (
    <div className="flex flex-col min-h-screen bg-background">
      {/* Hero Banner */}
      <section className="relative overflow-hidden bg-gradient-to-br from-slate-800 via-navy to-black geo-pattern">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-primary/20 rounded-full blur-[100px]" />
        
        <div className="container mx-auto px-4 max-w-6xl py-16 md:py-24 relative z-10 text-center">
          <div className="flex items-center justify-center text-sm font-bold text-slate-400 mb-6">
            <Link href="/" className="hover:text-white transition-colors">Beranda</Link>
            <ChevronRight className="h-4 w-4 mx-2" />
            <span className="text-white">Galeri</span>
          </div>

          <div className="inline-flex items-center justify-center p-3 bg-white/10 rounded-2xl mb-6 backdrop-blur-md border border-white/20">
            <Camera className="w-8 h-8 text-amber-400" />
          </div>
          
          <h1
            className="text-4xl md:text-6xl font-black text-white leading-tight mb-4"
            style={{ fontFamily: "var(--font-bitter)" }}
          >
            Galeri Warga
          </h1>
          <p className="text-slate-300 text-lg font-medium max-w-2xl mx-auto">
            Dokumentasi momen-momen kebersamaan, kegiatan, dan pembangunan di lingkungan RW 10 Desa Cicadas.
          </p>
        </div>
      </section>

      {/* Main Content */}
      <div className="container mx-auto px-4 max-w-6xl py-16">
        <GalleryClient items={dummyGallery} />
      </div>
    </div>
  );
}
