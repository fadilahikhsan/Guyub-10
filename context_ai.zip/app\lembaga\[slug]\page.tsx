import Link from "next/link";
import { notFound } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { ChevronRight, Calendar, Users, MapPin, Clock, Megaphone } from "lucide-react";

export const revalidate = 0;

// Mapping slug URL ke nama penyelenggara di database
const SLUG_MAP: Record<string, string> = {
  "rt-01": "RT 01",
  "rt-02": "RT 02",
  "rt-03": "RT 03",
  "rt-04": "RT 04",
  "karang-taruna": "Karang Taruna",
  "pkk": "PKK",
  "posyandu": "Posyandu",
};

// Data statis profil untuk tiap lembaga
const PROFIL_LEMBAGA: Record<string, { title: string; desc: string; icon: any; color: string }> = {
  "RT 01": { title: "Rukun Tetangga 01", desc: "Pusat informasi dan kegiatan warga wilayah RT 01.", icon: Users, color: "from-blue-600 to-blue-800" },
  "RT 02": { title: "Rukun Tetangga 02", desc: "Pusat informasi dan kegiatan warga wilayah RT 02.", icon: Users, color: "from-blue-600 to-blue-800" },
  "RT 03": { title: "Rukun Tetangga 03", desc: "Pusat informasi dan kegiatan warga wilayah RT 03.", icon: Users, color: "from-blue-600 to-blue-800" },
  "RT 04": { title: "Rukun Tetangga 04", desc: "Pusat informasi dan kegiatan warga wilayah RT 04.", icon: Users, color: "from-blue-600 to-blue-800" },
  "Karang Taruna": { title: "Karang Taruna (Pokja 10)", desc: "Wadah pengembangan generasi muda, tempat berkarya, dan berinovasi untuk kemajuan desa.", icon: Users, color: "from-indigo-600 to-purple-800" },
  "PKK": { title: "Pemberdayaan Kesejahteraan Keluarga", desc: "Gerakan nasional dalam pembangunan masyarakat yang tumbuh dari bawah.", icon: Users, color: "from-pink-500 to-rose-700" },
  "Posyandu": { title: "Pos Pelayanan Terpadu", desc: "Pusat kegiatan kesehatan dasar yang diselenggarakan dari, oleh, dan untuk masyarakat.", icon: Users, color: "from-emerald-500 to-teal-700" },
};

export default async function LembagaPage({ params }: { params: { slug: string } }) {
  const penyelenggara = SLUG_MAP[params.slug];
  
  if (!penyelenggara) {
    notFound();
  }

  const profil = PROFIL_LEMBAGA[penyelenggara];
  const supabase = await createClient();

  // Ambil kegiatan khusus penyelenggara ini
  const { data: kegiatanData } = await supabase
    .from("kegiatan")
    .select("*")
    .eq("penyelenggara", penyelenggara)
    .order("tanggal", { ascending: true });

  // Ambil pengumuman khusus penyelenggara ini
  const { data: pengumumanData } = await supabase
    .from("pengumuman")
    .select("*")
    .eq("penyelenggara", penyelenggara)
    .order("created_at", { ascending: false })
    .limit(5);

  const kegiatan = kegiatanData || [];
  const pengumuman = pengumumanData || [];

  return (
    <div className="flex flex-col min-h-screen bg-background">
      {/* Hero Banner Khusus Lembaga */}
      <section className={`relative overflow-hidden bg-gradient-to-br ${profil.color} geo-pattern`}>
        <div className="absolute top-8 right-8 w-48 h-48 border border-white/10 rounded-full" />
        <div className="absolute -bottom-12 -left-12 w-64 h-64 bg-white/5 rounded-full blur-3xl" />

        <div className="container mx-auto px-4 max-w-6xl py-12 md:py-16 relative z-10">
          <div className="flex items-center text-sm font-bold text-white/70 mb-6">
            <Link href="/" className="hover:text-white transition-colors">Beranda</Link>
            <ChevronRight className="h-4 w-4 mx-2" />
            <span className="text-white">{penyelenggara}</span>
          </div>

          <div className="flex items-center gap-4 mb-4">
            <div className="p-3 bg-white/10 rounded-2xl backdrop-blur-md border border-white/20">
              <profil.icon className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-3xl md:text-5xl font-black text-white leading-tight" style={{ fontFamily: "var(--font-bitter)" }}>
              {profil.title}
            </h1>
          </div>
          <p className="text-white/90 text-lg font-medium max-w-2xl mt-4">
            {profil.desc}
          </p>
        </div>
      </section>

      {/* Main Content */}
      <div className="container mx-auto px-4 max-w-6xl py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Kolom Kiri: Kegiatan */}
          <div className="lg:col-span-2 space-y-6">
            <div className="flex items-center gap-2 border-b pb-3">
              <Calendar className="w-6 h-6 text-primary" />
              <h2 className="text-2xl font-black text-foreground" style={{ fontFamily: "var(--font-bitter)" }}>
                Program & Kegiatan
              </h2>
            </div>

            {kegiatan.length === 0 ? (
              <div className="bg-card border border-border rounded-2xl p-8 text-center shadow-sm">
                <Calendar className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
                <h3 className="font-bold text-lg mb-1">Belum Ada Kegiatan</h3>
                <p className="text-sm text-muted-foreground">Belum ada agenda kegiatan yang tercatat untuk lembaga ini.</p>
              </div>
            ) : (
              <div className="space-y-4">
                {kegiatan.map((item) => (
                  <div key={item.id} className="bg-card border border-border/60 rounded-2xl p-5 shadow-sm flex flex-col sm:flex-row gap-5">
                    <div className="flex-shrink-0 flex flex-col items-center justify-center bg-muted/50 rounded-xl px-4 py-3 min-w-[100px] text-center border border-border">
                      <span className="text-xs font-bold text-muted-foreground uppercase mb-1">
                        {new Date(item.tanggal).toLocaleDateString("id-ID", { month: "short" })}
                      </span>
                      <span className="text-3xl font-black text-primary leading-none">
                        {new Date(item.tanggal).getDate()}
                      </span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <span className="inline-block text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full bg-blue-100 text-blue-700 mb-2">
                        {item.kategori}
                      </span>
                      <h3 className="text-lg font-bold text-foreground mb-1">{item.judul}</h3>
                      <p className="text-sm text-muted-foreground line-clamp-2 mb-3">{item.deskripsi}</p>
                      <div className="flex flex-wrap items-center gap-3 mt-auto">
                        <div className="flex items-center text-xs font-medium text-slate-500">
                          <Clock className="w-3.5 h-3.5 mr-1 text-slate-400" />
                          {new Date(item.tanggal).toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit" })} WIB
                        </div>
                        <div className="flex items-center text-xs font-medium text-slate-500">
                          <MapPin className="w-3.5 h-3.5 mr-1 text-slate-400" />
                          {item.lokasi}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Kolom Kanan: Pengumuman / Berita Lembaga */}
          <div className="space-y-6">
            <div className="flex items-center gap-2 border-b pb-3">
              <Megaphone className="w-6 h-6 text-amber-500" />
              <h2 className="text-2xl font-black text-foreground" style={{ fontFamily: "var(--font-bitter)" }}>
                Informasi Terbaru
              </h2>
            </div>

            {pengumuman.length === 0 ? (
              <div className="bg-card border border-border rounded-2xl p-6 text-center shadow-sm">
                <p className="text-sm text-muted-foreground">Belum ada informasi terbaru.</p>
              </div>
            ) : (
              <div className="space-y-4">
                {pengumuman.map((item) => (
                  <div key={item.id} className="bg-card border border-border rounded-2xl p-4 shadow-sm hover:border-primary/50 transition-colors">
                    <div className="flex items-center gap-2 mb-2">
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider ${
                        item.kategori === 'Penting' ? 'bg-red-100 text-red-700' : 'bg-emerald-100 text-emerald-700'
                      }`}>
                        {item.kategori}
                      </span>
                      <span className="text-xs text-muted-foreground">
                        {new Date(item.created_at).toLocaleDateString("id-ID", { day: "numeric", month: "short" })}
                      </span>
                    </div>
                    <h4 className="font-bold text-foreground text-sm mb-1">{item.judul}</h4>
                    <p className="text-xs text-muted-foreground line-clamp-2">{item.konten}</p>
                  </div>
                ))}
              </div>
            )}
          </div>

        </div>
      </div>
    </div>
  );
}
