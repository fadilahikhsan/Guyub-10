import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

export default async function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const supabase = await createClient();
  let { data: { user } } = await supabase.auth.getUser();

  // BYPASS AUTH SEMENTARA
  if (!user) {
    user = { email: "admin@bypassed.com", id: "dummy-bypass" } as any;
  }

  // Cek ROLE Admin (Dinonaktifkan sementara)
  // const { data: profile } = await supabase.from('profiles').select('role').eq('id', user.id).single();
  
  // if (profile?.role !== 'admin') {
  //   redirect("/");
  // }

  return (
    <div className="min-h-screen bg-zinc-50 flex flex-col">
      {/* Admin Sidebar & Header disederhanakan dalam layout tunggal */}
      <header className="bg-primary text-primary-foreground p-4 md:p-6 shadow-md">
        <div className="container mx-auto flex items-center justify-between">
          <h1 className="text-2xl font-black">Admin Guyub</h1>
          <div className="text-sm font-bold bg-white/20 px-4 py-2 rounded-xl">
            {user.email}
          </div>
        </div>
      </header>
      <main className="flex-1 container mx-auto p-4 md:p-8">
        {children}
      </main>
    </div>
  );
}
