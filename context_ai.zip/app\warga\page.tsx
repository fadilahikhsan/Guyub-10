import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import { FileText, Store, User, MapPin, ChevronRight, PlusCircle, CheckCircle2, Clock, XCircle } from "lucide-react";
import Link from "next/link";
import UmkmForm from "./UmkmForm";

export const revalidate = 0;

export default async function WargaDashboardPage() {
  const supabase = await createClient();
  let { data: { user } } = await supabase.auth.getUser();

  if (!user) {
    user = { id: 'dummy-warga', email: 'warga@bypassed.com' } as any;
  }

  // Fetch all related data
  const [
    { data: profile },
    { data: suratList },
    { data: umkmList }
  ] = await Promise.all([
    supabase.from("profiles").select("*").eq("id", user.id).single(),
    supabase.from("surat").select("*").eq("user_id", user.id).order("created_at", { ascending: false }),
    supabase.from("umkm").select("*").eq("owner_id", user.id).order("created_at", { ascending: false })
  ]);

  const getStatusBadge = (status: string) => {
    switch (status.toLowerCase()) {
      case "selesai":
        return <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-700"><CheckCircle2 className="w-3.5 h-3.5" /> Selesai</span>;
      case "ditolak":
        return <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-red-100 text-red-700"><XCircle className="w-3.5 h-3.5" /> Ditolak</span>;
      case "diproses":
        return <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-blue-100 text-blue-700"><Clock className="w-3.5 h-3.5" /> Diproses</span>;
      default:
        return <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-amber-100 text-amber-700"><Clock className="w-3.5 h-3.5" /> Pending</span>;
    }
  };

  return (
    <div className="flex flex-col min-h-screen pt-24 pb-20 bg-background">
      <section className="container mx-auto px-4 max-w-6xl mb-8">
        <div className="flex items-center text-sm font-bold text-muted-foreground mb-6">
          <Link href="/" className="hover:text-primary transition-colors">Beranda</Link>
          <ChevronRight className="h-4 w-4 mx-2" />
          <span className="text-foreground">Dasbor Warga</span>
        </div>
        <h1 className="text-3xl md:text-5xl font-black tracking-tight mb-2 text-foreground" style={{ fontFamily: "var(--font-bitter)" }}>
          Dasbor Saya
        </h1>
        <p className="text-lg text-muted-foreground font-medium">
          Kelola profil, riwayat surat, dan pendaftaran UMKM Anda.
        </p>
      </section>

      <section className="container mx-auto px-4 max-w-6xl space-y-8">
        
        {/* Row 1: Profile Card */}
        <div className="bg-white rounded-3xl p-6 md:p-8 border border-border shadow-sm flex flex-col md:flex-row gap-6 items-start md:items-center">
          <div className="w-20 h-20 bg-primary/10 text-primary rounded-full flex items-center justify-center flex-shrink-0">
            <User className="w-10 h-10" />
          </div>
          <div className="flex-1">
            <h2 className="text-2xl font-black mb-1 text-foreground">{profile?.nama_lengkap || "Warga"}</h2>
            <div className="flex flex-wrap items-center gap-4 text-sm font-medium text-muted-foreground">
              <span className="flex items-center gap-1.5 bg-gray-100 px-3 py-1 rounded-lg">
                NIK: {profile?.nik}
              </span>
              <span className="flex items-center gap-1.5 bg-gray-100 px-3 py-1 rounded-lg">
                <MapPin className="w-4 h-4" /> RT {profile?.rt} / RW {profile?.rw}
              </span>
            </div>
          </div>
          {profile?.role === 'admin' && (
            <div className="flex-shrink-0 mt-4 md:mt-0 w-full md:w-auto">
              <Link href="/admin" className="w-full flex items-center justify-center gap-2 bg-primary text-white font-bold px-6 py-3 rounded-xl hover:bg-blue-700 transition-colors shadow-sm">
                Ke Dashboard Admin
              </Link>
            </div>
          )}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Kolom Kiri: Riwayat Surat */}
          <div className="bg-white rounded-3xl p-6 md:p-8 border border-border shadow-sm flex flex-col h-full">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <div className="bg-blue-100 text-blue-600 p-2.5 rounded-xl">
                  <FileText className="w-5 h-5" />
                </div>
                <h3 className="text-xl font-black text-foreground" style={{ fontFamily: "var(--font-bitter)" }}>Riwayat Surat</h3>
              </div>
              <Link href="/layanan" className="text-sm font-bold text-primary hover:underline flex items-center gap-1">
                <PlusCircle className="w-4 h-4" /> Ajukan
              </Link>
            </div>

            <div className="flex-1">
              {(!suratList || suratList.length === 0) ? (
                <div className="h-full min-h-[200px] flex flex-col items-center justify-center text-center p-6 border-2 border-dashed border-border rounded-2xl">
                  <FileText className="w-12 h-12 text-muted-foreground/30 mb-3" />
                  <p className="text-muted-foreground font-medium text-sm">Belum ada surat yang diajukan.</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {suratList.map((surat) => (
                    <div key={surat.id} className="border border-border rounded-2xl p-4 hover:border-primary/50 transition-colors">
                      <div className="flex justify-between items-start mb-2">
                        <h4 className="font-bold text-foreground">{surat.jenis_surat}</h4>
                        {getStatusBadge(surat.status)}
                      </div>
                      <p className="text-sm text-muted-foreground line-clamp-2 mb-3">{surat.keperluan}</p>
                      
                      {surat.catatan_admin && (
                        <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 mt-3">
                          <p className="text-xs font-bold text-amber-800 mb-1">Catatan Pengurus:</p>
                          <p className="text-xs text-amber-700">{surat.catatan_admin}</p>
                        </div>
                      )}
                      <p className="text-xs text-muted-foreground/70 mt-3 flex justify-end">
                        {new Date(surat.created_at).toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' })}
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Kolom Kanan: UMKM Saya */}
          <div className="bg-white rounded-3xl p-6 md:p-8 border border-border shadow-sm flex flex-col h-full">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <div className="bg-emerald-100 text-emerald-600 p-2.5 rounded-xl">
                  <Store className="w-5 h-5" />
                </div>
                <h3 className="text-xl font-black text-foreground" style={{ fontFamily: "var(--font-bitter)" }}>Usaha Saya (UMKM)</h3>
              </div>
            </div>

            <div className="flex-1 space-y-6">
              {(!umkmList || umkmList.length === 0) ? (
                <div className="h-full min-h-[200px] flex flex-col items-center justify-center text-center p-6 border-2 border-dashed border-border rounded-2xl">
                  <Store className="w-12 h-12 text-muted-foreground/30 mb-3" />
                  <p className="text-muted-foreground font-medium text-sm">Anda belum mendaftarkan usaha/UMKM apapun.</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {umkmList.map((umkm) => (
                    <div key={umkm.id} className="border border-border rounded-2xl p-4">
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <h4 className="font-bold text-foreground text-lg">{umkm.nama_usaha}</h4>
                          <span className="text-xs font-bold text-muted-foreground uppercase tracking-wider">{umkm.kategori}</span>
                        </div>
                        {umkm.is_approved ? (
                          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-700">Terverifikasi</span>
                        ) : (
                          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-amber-100 text-amber-700">Menunggu Review</span>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground mb-3">{umkm.deskripsi}</p>
                      <p className="text-xs font-bold text-primary">WA: {umkm.nomor_wa}</p>
                    </div>
                  ))}
                </div>
              )}

              {/* Form Tambah UMKM */}
              <div className="pt-6 border-t border-border">
                <h4 className="font-black text-lg mb-4 text-foreground">Daftarkan Usaha Baru</h4>
                <UmkmForm />
              </div>
            </div>
          </div>
        </div>

      </section>
    </div>
  );
}
