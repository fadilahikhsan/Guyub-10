"use server";

import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";

// ── Surat Actions ─────────────────────────────────────────────
export async function updateSuratStatus(suratId: string, status: "diproses" | "selesai" | "ditolak", catatan?: string) {
  const supabase = await createClient();

  const { error } = await supabase
    .from("surat")
    .update({ status, catatan_admin: catatan ?? null })
    .eq("id", suratId);

  if (error) return { error: error.message };

  revalidatePath("/admin");
  return { success: true };
}

// ── Pengumuman Actions ────────────────────────────────────────
export async function createPengumuman(formData: FormData) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  const judul = formData.get("judul") as string;
  const konten = formData.get("konten") as string;
  const kategori = formData.get("kategori") as string;
  const penyelenggara = formData.get("penyelenggara") as string || "Pengurus RW";

  if (!judul || !konten || !kategori) return { error: "Semua field harus diisi." };

  const { error } = await supabase.from("pengumuman").insert({
    judul,
    konten,
    kategori,
    penyelenggara,
    created_by: user?.id,
  });

  if (error) return { error: error.message };

  revalidatePath("/admin");
  revalidatePath("/informasi");
  revalidatePath("/");
  return { success: true };
}

export async function deletePengumuman(id: string) {
  const supabase = await createClient();

  const { error } = await supabase.from("pengumuman").delete().eq("id", id);

  if (error) return { error: error.message };

  revalidatePath("/admin");
  revalidatePath("/informasi");
  revalidatePath("/");
  return { success: true };
}

export async function updatePengumuman(id: string, formData: FormData) {
  const supabase = await createClient();

  const judul = formData.get("judul") as string;
  const konten = formData.get("konten") as string;
  const kategori = formData.get("kategori") as string;
  const penyelenggara = formData.get("penyelenggara") as string || "Pengurus RW";

  if (!judul || !konten || !kategori) return { error: "Semua field harus diisi." };

  const { error } = await supabase.from("pengumuman").update({ judul, konten, kategori, penyelenggara }).eq("id", id);

  if (error) return { error: error.message };

  revalidatePath("/admin");
  revalidatePath("/informasi");
  revalidatePath("/");
  return { success: true };
}

// ──────────────────────────────────────────────────────────
// KEGIATAN ACTIONS
// ──────────────────────────────────────────────────────────

export async function createKegiatan(formData: FormData) {
  try {
    const supabase = await createClient();
    const { data: { user } } = await supabase.auth.getUser();

    if (!user) {
      return { success: false, error: "Unauthorized" };
    }

    const { data: profile } = await supabase
      .from("profiles")
      .select("role")
      .eq("id", user.id)
      .single();

    if (profile?.role !== "admin") {
      return { success: false, error: "Only admins can create kegiatan" };
    }

    const judul = formData.get("judul") as string;
    const deskripsi = formData.get("deskripsi") as string;
    const lokasi = formData.get("lokasi") as string;
    const kategori = formData.get("kategori") as string;
    const penyelenggara = formData.get("penyelenggara") as string || "Pengurus RW";
    
    // Parse tanggal dan waktu (asumsi format input type datetime-local)
    const tanggalInput = formData.get("tanggal") as string; 
    const tanggal = new Date(tanggalInput).toISOString();

    const { error } = await supabase.from("kegiatan").insert({
      judul,
      deskripsi,
      tanggal,
      lokasi,
      kategori,
      penyelenggara,
    });

    if (error) throw error;

    revalidatePath("/admin");
    revalidatePath("/kegiatan");
    return { success: true };
  } catch (err: any) {
    return { success: false, error: err.message || "Failed to create kegiatan" };
  }
}

export async function updateKegiatan(id: string, formData: FormData) {
  try {
    const supabase = await createClient();
    // verifikasi
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return { success: false, error: "Unauthorized" };

    const judul = formData.get("judul") as string;
    const deskripsi = formData.get("deskripsi") as string;
    const lokasi = formData.get("lokasi") as string;
    const kategori = formData.get("kategori") as string;
    const penyelenggara = formData.get("penyelenggara") as string || "Pengurus RW";
    const tanggalInput = formData.get("tanggal") as string;
    const tanggal = new Date(tanggalInput).toISOString();

    const { error } = await supabase
      .from("kegiatan")
      .update({
        judul,
        deskripsi,
        tanggal,
        lokasi,
        kategori,
        penyelenggara,
      })
      .eq("id", id);

    if (error) throw error;

    revalidatePath("/admin");
    revalidatePath("/kegiatan");
    return { success: true };
  } catch (err: any) {
    return { success: false, error: err.message || "Failed to update kegiatan" };
  }
}

export async function deleteKegiatan(id: string) {
  try {
    const supabase = await createClient();
    const { error } = await supabase.from("kegiatan").delete().eq("id", id);
    if (error) throw error;

    revalidatePath("/admin");
    revalidatePath("/kegiatan");
    return { success: true };
  } catch (err: any) {
    return { success: false, error: err.message || "Failed to delete kegiatan" };
  }
}

// ──────────────────────────────────────────────────────────
// UMKM ACTIONS
// ──────────────────────────────────────────────────────────

export async function updateUmkmStatus(id: string, is_approved: boolean) {
  try {
    const supabase = await createClient();
    const { error } = await supabase.from("umkm").update({ is_approved }).eq("id", id);
    if (error) throw error;

    revalidatePath("/admin");
    revalidatePath("/umkm");
    return { success: true };
  } catch (err: any) {
    return { success: false, error: err.message || "Gagal mengubah status UMKM" };
  }
}

export async function deleteUmkm(id: string) {
  try {
    const supabase = await createClient();
    const { error } = await supabase.from("umkm").delete().eq("id", id);
    if (error) throw error;

    revalidatePath("/admin");
    revalidatePath("/umkm");
    return { success: true };
  } catch (err: any) {
    return { success: false, error: err.message || "Gagal menghapus UMKM" };
  }
}
