import Link from "next/link";
import {
  FileText,
  Store,
  AlertTriangle,
  ChevronRight,
  Calendar,
  Users,
  Activity,
  Megaphone,
  TrendingUp,
  ArrowRight,
  Zap,
} from "lucide-react";

import { createClient } from "@/lib/supabase/server";

export default async function Home() {
  const supabase = await createClient();

  const { data: articlesList } = await supabase
    .from("pengumuman")
    .select("*")
    .order("created_at", { ascending: false })
    .limit(5);

  const { count: countProfiles } = await supabase.from('profiles').select('*', { count: 'exact', head: true });
  const { count: countUmkm } = await supabase.from('umkm').select('*', { count: 'exact', head: true });
  const { count: countSurat } = await supabase.from('surat').select('*', { count: 'exact', head: true });

  const stats = [
    {
      icon: Users,
      label: "Total Warga",
      value: countProfiles?.toString() || "0",
      unit: "Jiwa",
      color: "text-primary",
      bg: "bg-blue-50",
    },
    {
      icon: Store,
      label: "UMKM Terdaftar",
      value: countUmkm?.toString() || "0",
      unit: "Usaha",
      color: "text-amber-500",
      bg: "bg-amber-50",
    },
    {
      icon: FileText,
      label: "Surat Terbit",
      value: countSurat?.toString() || "0",
      unit: "Dokumen",
      color: "text-emerald-600",
      bg: "bg-emerald-50",
    },
    {
      icon: Activity,
      label: "Kunjungan",
      value: "8.9K",
      unit: "Kali",
      color: "text-purple-600",
      bg: "bg-purple-50",
    },
  ];

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('id-ID', {
      day: 'numeric',
      month: 'short',
      year: 'numeric'
    });
  };

  return (
    <div className="flex flex-col min-h-screen bg-background">

      {/* ── Running Text / Ticker ───────────────────── */}
      <div className="w-full bg-primary text-white overflow-hidden py-2.5 border-b border-blue-700/40 flex items-center shadow-sm">
        <div className="bg-amber-500 text-[#0f172a] px-4 py-1 font-black text-xs uppercase z-10 whitespace-nowrap tracking-wider flex items-center gap-1.5">
          <Zap className="w-3 h-3" />
          Info Penting
        </div>
        <div className="whitespace-nowrap animate-marquee flex items-center pl-4 text-sm font-medium">
          <span className="mx-10">
            🚨 <strong className="font-bold">Kerja Bakti:</strong> Minggu, 20
            Juni 2026 pukul 07:00 di lapangan utama. Wajib hadir perwakilan tiap
            KK.
          </span>
          <span className="mx-10">
            💰 <strong className="font-bold">Iuran Kas:</strong> Laporan bulan
            Mei sudah terbit. Silakan cek di menu Informasi Publik.
          </span>
          <span className="mx-10">
            🦟 <strong className="font-bold">Kesehatan:</strong> Jadwal fogging
            DBD RT 01 s/d RT 05 hari Sabtu sore.
          </span>
        </div>
      </div>

      <div className="container mx-auto px-4 max-w-6xl py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">

          {/* ── Main Content ──────────────────────────── */}
          <div className="lg:col-span-2 space-y-8">

            {/* Hero / Featured Article */}
            <section
              className="relative rounded-2xl overflow-hidden shadow-lg card-hover fade-in-up"
              aria-label="Artikel Utama"
            >
              {/* Background gradient with geo pattern */}
              <div className="h-72 sm:h-80 md:h-[420px] bg-gradient-to-br from-[#1a56db] via-[#2563eb] to-[#0f172a] geo-pattern relative">
                {/* Decorative rings */}
                <div className="absolute top-6 right-6 w-32 h-32 border border-white/10 rounded-full" />
                <div className="absolute top-12 right-12 w-20 h-20 border border-white/10 rounded-full" />
                <div className="absolute -bottom-8 -left-8 w-48 h-48 bg-white/5 rounded-full blur-2xl" />

                {/* Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />

                {/* Content */}
                <div className="absolute bottom-0 left-0 p-6 md:p-8 w-full">
                  <span className="inline-flex items-center gap-1.5 bg-amber-500 text-[#0f172a] text-xs font-black px-3 py-1 rounded-full uppercase tracking-wider mb-4">
                    <TrendingUp className="w-3 h-3" />
                    Berita Utama
                  </span>
                  <div className="text-3xl md:text-5xl lg:text-6xl font-black text-white leading-tight mb-4 tracking-tight drop-shadow-xl" style={{ fontFamily: "var(--font-bitter)" }}>
                Portal Digital <br className="hidden md:block" />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-300 to-yellow-500">
                  RW 10 Desa Cicadas
                </span>
              </div>
              <p className="text-blue-50 text-base md:text-lg font-medium max-w-xl mb-8 leading-relaxed shadow-sm">
                Sistem informasi dan pelayanan warga terpadu. Membangun lingkungan yang
                harmonis, transparan, dan maju bersama warga RW 10.
              </p>
                  <div className="flex flex-wrap items-center text-gray-300 text-xs md:text-sm font-medium gap-4">
                    <span className="flex items-center gap-1.5">
                      <Calendar className="w-4 h-4" />
                      {articlesList && articlesList.length > 0 ? formatDate(articlesList[0].created_at) : "15 Juni 2026"}
                    </span>
                    <span className="flex items-center gap-1.5">
                      <Users className="w-4 h-4" />
                      Oleh Pengurus RW
                    </span>
                    <Link
                      href="/informasi"
                      className="ml-auto flex items-center gap-1 text-amber-400 hover:text-amber-300 font-bold transition-colors text-xs"
                    >
                      Baca Selengkapnya <ArrowRight className="w-3.5 h-3.5" />
                    </Link>
                  </div>
                </div>
              </div>
            </section>

            {/* Latest News Section */}
            <section>
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-3">
                  <div className="w-1 h-7 bg-primary rounded-full" />
                  <h2
                    className="text-xl font-black text-foreground uppercase tracking-tight"
                    style={{ fontFamily: "var(--font-bitter)" }}
                  >
                    Berita Terkini
                  </h2>
                </div>
                <Link
                  href="/informasi"
                  className="text-sm font-bold text-primary hover:text-primary/80 flex items-center gap-1 transition-colors group"
                >
                  Semua Berita
                  <ChevronRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
                </Link>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                {articlesList && articlesList.slice(1).map((article, i) => {
                  const isPenting = article.kategori.toLowerCase() === "penting" || article.kategori.toLowerCase() === "darurat";
                  const categoryStyle = isPenting ? "badge-red border-top-red" : "badge-blue border-top-blue";
                  const bg = isPenting ? "from-red-500/20 to-rose-500/10" : "from-blue-500/20 to-indigo-500/10";
                  
                  return (
                  <article
                    key={article.id}
                    className={`bg-card rounded-2xl overflow-hidden shadow-sm card-hover border border-border/60 fade-in-up fade-in-up-delay-${i + 1} ${categoryStyle.split(" ")[1]}`}
                  >
                    {/* Colored image placeholder with gradient */}
                    <div
                      className={`h-44 bg-gradient-to-br ${bg} relative overflow-hidden`}
                    >
                      <div className="absolute inset-0 flex items-center justify-center opacity-20">
                        <Megaphone className="w-24 h-24 text-gray-600" />
                      </div>
                    </div>

                    <div className="p-5">
                      <span
                        className={`inline-block text-xs font-bold uppercase tracking-wider px-2.5 py-1 rounded-full mb-3 ${categoryStyle.split(" ")[0]}`}
                      >
                        {article.kategori}
                      </span>
                      <h3
                        className="text-base font-bold mb-2 leading-snug hover:text-primary transition-colors line-clamp-2"
                        style={{ fontFamily: "var(--font-bitter)" }}
                      >
                        <Link href="/informasi">{article.judul}</Link>
                      </h3>
                      <p className="text-muted-foreground text-sm mb-4 line-clamp-2 leading-relaxed">
                        {article.konten}
                      </p>
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-muted-foreground font-medium flex items-center gap-1">
                          <Calendar className="w-3.5 h-3.5" />
                          {formatDate(article.created_at)}
                        </span>
                        <Link
                          href="/informasi"
                          className="text-xs font-bold text-primary hover:underline flex items-center gap-0.5"
                        >
                          Baca <ArrowRight className="w-3 h-3" />
                        </Link>
                      </div>
                    </div>
                  </article>
                )})}
              </div>
            </section>
          </div>

          {/* ── Sidebar ───────────────────────────────── */}
          <div className="space-y-6">

            {/* Quick Access Widget */}
            <div className="bg-card rounded-2xl border border-border/60 shadow-sm overflow-hidden">
              <div className="bg-gradient-to-r from-primary to-blue-600 p-4">
                <h3
                  className="text-sm font-black uppercase text-white tracking-wider"
                  style={{ fontFamily: "var(--font-bitter)" }}
                >
                  Layanan Warga
                </h3>
                <p className="text-xs text-blue-100 mt-0.5">Akses cepat layanan digital</p>
              </div>
              <div className="p-4 space-y-2">
                {[
                  {
                    href: "/layanan",
                    icon: FileText,
                    label: "Surat Pengantar",
                    sub: "Pengajuan online 24/7",
                    color: "bg-blue-50 text-primary group-hover:bg-primary group-hover:text-white",
                  },
                  {
                    href: "/umkm",
                    icon: Store,
                    label: "Direktori UMKM",
                    sub: "Belanja dari warga lokal",
                    color: "bg-amber-50 text-amber-600 group-hover:bg-amber-500 group-hover:text-white",
                  },
                  {
                    href: "/informasi",
                    icon: Megaphone,
                    label: "Papan Informasi",
                    sub: "Berita & laporan kas",
                    color: "bg-emerald-50 text-emerald-600 group-hover:bg-emerald-500 group-hover:text-white",
                  },
                ].map((item) => (
                  <Link
                    key={item.href}
                    href={item.href}
                    className="flex items-center p-3 rounded-xl border border-border/60 hover:border-primary/30 hover:bg-muted/50 transition-all group"
                  >
                    <div className={`p-2 rounded-lg mr-3 transition-all duration-200 ${item.color}`}>
                      <item.icon className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="font-bold text-sm text-foreground">{item.label}</div>
                      <div className="text-xs text-muted-foreground">{item.sub}</div>
                    </div>
                    <ChevronRight className="w-4 h-4 ml-auto text-muted-foreground group-hover:text-primary group-hover:translate-x-0.5 transition-all" />
                  </Link>
                ))}

                {/* Emergency button */}
                <Link
                  href="/darurat"
                  className="flex items-center p-3 rounded-xl bg-red-50 border border-red-200 hover:bg-destructive hover:border-destructive group transition-all duration-200"
                >
                  <div className="p-2 rounded-lg mr-3 bg-red-100 text-destructive group-hover:bg-red-400 group-hover:text-white transition-all duration-200">
                    <AlertTriangle className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="font-bold text-sm text-destructive group-hover:text-white transition-colors">
                      Lapor Darurat
                    </div>
                    <div className="text-xs text-red-400 group-hover:text-red-100 transition-colors">
                      Kontak penting 24 jam
                    </div>
                  </div>
                  <span className="ml-auto w-2 h-2 bg-destructive group-hover:bg-white rounded-full animate-pulse transition-colors" />
                </Link>
              </div>
            </div>

            {/* Sambutan Ketua RW */}
            <div className="bg-card rounded-2xl border border-border/60 shadow-sm overflow-hidden">
              <div className="bg-gradient-to-r from-[#0f172a] to-slate-800 p-4">
                <h3
                  className="text-sm font-black uppercase text-white tracking-wider"
                  style={{ fontFamily: "var(--font-bitter)" }}
                >
                  Sambutan Ketua RW
                </h3>
              </div>
              <div className="p-5 text-center">
                {/* Avatar */}
                <div className="relative inline-block mb-4">
                  <div className="w-20 h-20 bg-gradient-to-br from-primary/30 to-blue-200 rounded-full border-4 border-white shadow-lg flex items-center justify-center">
                    <Users className="w-8 h-8 text-primary/60" />
                  </div>
                  <span className="absolute -bottom-1 -right-1 bg-emerald-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full">
                    RW
                  </span>
                </div>
                <h4 className="font-black text-base text-foreground">Bpk. H. Ahmad</h4>
                <p className="text-xs text-muted-foreground mb-4 uppercase tracking-wider font-semibold">
                  Ketua RW 10
                </p>
                <blockquote className="text-sm italic text-slate-500 leading-relaxed border-l-2 border-primary/30 pl-3 text-left">
                  &ldquo;Selamat datang di Portal Digital Guyub RW 10. Kami berharap
                  platform ini menjadikan pelayanan warga lebih cepat, transparan, dan
                  mempererat silaturahmi.&rdquo;
                </blockquote>
              </div>
            </div>

            {/* Stats Widget */}
            <div className="bg-card rounded-2xl border border-border/60 shadow-sm overflow-hidden">
              <div className="bg-gradient-to-r from-primary to-blue-600 p-4">
                <h3
                  className="text-sm font-black uppercase text-white tracking-wider"
                  style={{ fontFamily: "var(--font-bitter)" }}
                >
                  Statistik Warga
                </h3>
                <p className="text-xs text-blue-100 mt-0.5">Data per Juni 2026</p>
              </div>
              <div className="p-4 space-y-3">
                {stats.map((stat) => (
                  <div
                    key={stat.label}
                    className="flex items-center gap-3 p-3 rounded-xl hover:bg-muted/40 transition-colors"
                  >
                    <div className={`p-2 rounded-xl ${stat.bg}`}>
                      <stat.icon className={`w-4 h-4 ${stat.color}`} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-xs text-muted-foreground font-medium truncate">
                        {stat.label}
                      </div>
                    </div>
                    <div className="text-right">
                      <span className={`font-black text-base ${stat.color}`}>
                        {stat.value}
                      </span>
                      <span className="text-xs text-muted-foreground ml-1">
                        {stat.unit}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

          </div>
          {/* end sidebar */}

        </div>
      </div>
    </div>
  );
}
