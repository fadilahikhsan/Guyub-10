import Link from "next/link";
import {
  ChevronRight,
  Users,
  Target,
  Eye,
  Award,
  Phone,
  Mail,
  MapPin,
  Clock,
  Shield,
  Heart,
  Leaf,
  Star,
  Map,
  Building,
} from "lucide-react";

/* ─── Data Pengurus ─────────────────────────────────── */
const pengurusHarian = {
  ketua: {
    jabatan: "Ketua RW",
    nama: "Bpk. H. Ahmad Fauzi",
    no_hp: "0812-3456-7890",
    color: "from-amber-400 to-orange-500",
    badgeColor: "bg-amber-100 text-amber-700 border-amber-200",
  },
  sekretaris: {
    jabatan: "Sekretaris RW",
    nama: "Bpk. Dedi Kurniawan",
    no_hp: "0813-2345-6789",
    color: "from-blue-400 to-indigo-500",
    badgeColor: "bg-blue-100 text-blue-700 border-blue-200",
  },
  bendahara: {
    jabatan: "Bendahara RW",
    nama: "Ibu Siti Rahayu",
    no_hp: "0857-8765-4321",
    color: "from-emerald-400 to-teal-500",
    badgeColor: "bg-emerald-100 text-emerald-700 border-emerald-200",
  },
};

const lembagaList = [
  { name: "RT 01", slug: "rt-01", color: "bg-blue-50 text-blue-600 hover:bg-blue-600 hover:text-white border-blue-200", icon: Building },
  { name: "RT 02", slug: "rt-02", color: "bg-blue-50 text-blue-600 hover:bg-blue-600 hover:text-white border-blue-200", icon: Building },
  { name: "RT 03", slug: "rt-03", color: "bg-blue-50 text-blue-600 hover:bg-blue-600 hover:text-white border-blue-200", icon: Building },
  { name: "RT 04", slug: "rt-04", color: "bg-blue-50 text-blue-600 hover:bg-blue-600 hover:text-white border-blue-200", icon: Building },
  { name: "Karang Taruna", slug: "karang-taruna", color: "bg-indigo-50 text-indigo-600 hover:bg-indigo-600 hover:text-white border-indigo-200", icon: Users },
  { name: "PKK", slug: "pkk", color: "bg-pink-50 text-pink-600 hover:bg-pink-600 hover:text-white border-pink-200", icon: Heart },
  { name: "Posyandu", slug: "posyandu", color: "bg-emerald-50 text-emerald-600 hover:bg-emerald-600 hover:text-white border-emerald-200", icon: Shield },
];

const visiMisi = {
  visi:
    "Terwujudnya lingkungan RW 10 yang aman, nyaman, bersih, harmonis, dan mandiri dengan masyarakat yang aktif berpartisipasi dalam pembangunan berbasis kekeluargaan.",
  misi: [
    "Meningkatkan keamanan dan ketertiban lingkungan melalui sistem siskamling dan koordinasi yang efektif.",
    "Mendorong partisipasi aktif seluruh warga dalam kegiatan sosial, gotong royong, dan musyawarah.",
    "Memfasilitasi pelayanan administrasi kependudukan yang cepat, mudah, dan transparan bagi seluruh warga.",
    "Meningkatkan taraf ekonomi warga melalui pemberdayaan UMKM dan kegiatan ekonomi produktif.",
    "Menjaga kebersihan dan kelestarian lingkungan demi kesehatan dan kenyamanan bersama.",
    "Membangun komunikasi yang terbuka dan digital melalui Portal Guyub sebagai sarana informasi warga.",
  ],
};

/* ─── Page ──────────────────────────────────────────── */
export default function ProfilRWPage() {
  return (
    <div className="flex flex-col min-h-screen bg-background">
      {/* Hero Banner */}
      <section className="relative overflow-hidden bg-gradient-to-br from-[#1a56db] via-[#2563eb] to-[#0f172a] geo-pattern">
        <div className="absolute top-8 right-8 w-48 h-48 border border-white/10 rounded-full" />
        <div className="absolute top-16 right-16 w-32 h-32 border border-white/10 rounded-full" />
        <div className="absolute -bottom-12 -left-12 w-64 h-64 bg-white/5 rounded-full blur-3xl" />

        <div className="container mx-auto px-4 max-w-6xl py-16 md:py-20 relative z-10">
          <div className="flex items-center text-sm font-bold text-blue-200 mb-8">
            <Link href="/" className="hover:text-white transition-colors">Beranda</Link>
            <ChevronRight className="h-4 w-4 mx-2" />
            <span className="text-white">Profil RW</span>
          </div>

          <div className="flex flex-col md:flex-row md:items-center gap-8">
            <div className="flex-shrink-0">
              <div className="w-28 h-28 md:w-36 md:h-36 bg-white/15 backdrop-blur-sm border-2 border-white/30 rounded-3xl flex items-center justify-center shadow-2xl">
                <div className="text-center">
                  <div className="text-4xl md:text-5xl font-black text-white leading-none">10</div>
                  <div className="text-xs font-bold text-blue-200 uppercase tracking-widest mt-1">RW</div>
                </div>
              </div>
            </div>

            <div>
              <span className="inline-flex items-center gap-1.5 bg-amber-500 text-[#0f172a] text-xs font-black px-3 py-1 rounded-full uppercase tracking-wider mb-4">
                <Star className="w-3 h-3" />
                Profil Wilayah
              </span>
              <h1
                className="text-3xl md:text-5xl font-black text-white leading-tight mb-3"
                style={{ fontFamily: "var(--font-bitter)" }}
              >
                RW 10 Desa Cicadas
              </h1>
              <p className="text-blue-100 text-lg font-medium max-w-xl">
                Rukun Warga 10 — pusat pelayanan, kebersamaan, dan aspirasi masyarakat Desa Cicadas.
              </p>
            </div>
          </div>
        </div>
      </section>

      <div className="container mx-auto px-4 max-w-6xl py-12 space-y-16">

        {/* Lingkungan RW 10 (Map & Deskripsi) */}
        <section>
          <div className="flex items-center gap-3 mb-8">
            <div className="w-1 h-8 bg-primary rounded-full" />
            <h2 className="text-2xl font-black text-foreground uppercase tracking-tight" style={{ fontFamily: "var(--font-bitter)" }}>
              Profil Lingkungan
            </h2>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Teks Deskripsi */}
            <div className="bg-card border border-border/60 rounded-3xl p-8 shadow-sm">
              <h3 className="text-xl font-black text-primary mb-4">Wilayah RW 10 Desa Cicadas</h3>
              <p className="text-muted-foreground leading-relaxed mb-6">
                Rukun Warga (RW) 10 terletak di jantung Desa Cicadas, menaungi 4 Rukun Tetangga (RT) yang aktif dan rukun.
                Wilayah ini memiliki luas kurang lebih 15 hektar dengan populasi lebih dari 1.200 jiwa yang beragam dan harmonis.
                Lingkungan RW 10 dikenal dengan tingkat partisipasi warganya yang tinggi dalam berbagai program pemberdayaan,
                kesehatan (Posyandu), dan gerakan kepemudaan (Karang Taruna).
              </p>
              
              <div className="space-y-4">
                <div className="flex gap-4 items-start">
                  <div className="bg-blue-100 text-blue-600 p-2.5 rounded-xl flex-shrink-0">
                    <Map className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-bold text-sm text-foreground">Luas Wilayah</h4>
                    <p className="text-sm text-muted-foreground">± 15 Hektar, mencakup area perumahan dan fasilitas umum.</p>
                  </div>
                </div>
                <div className="flex gap-4 items-start">
                  <div className="bg-emerald-100 text-emerald-600 p-2.5 rounded-xl flex-shrink-0">
                    <Users className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-bold text-sm text-foreground">Populasi Warga</h4>
                    <p className="text-sm text-muted-foreground">4 RT dengan total lebih dari 350 Kepala Keluarga (KK).</p>
                  </div>
                </div>
                <div className="flex gap-4 items-start">
                  <div className="bg-amber-100 text-amber-600 p-2.5 rounded-xl flex-shrink-0">
                    <MapPin className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-bold text-sm text-foreground">Alamat Sekretariat</h4>
                    <p className="text-sm text-muted-foreground">Jalan Raya Cicadas No. 10, Balai Warga RW 10, Desa Cicadas.</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Embed Map */}
            <div className="rounded-3xl overflow-hidden border border-border/60 shadow-sm h-[400px] lg:h-auto relative bg-muted flex items-center justify-center">
              {/* Sebagai placeholder Google Maps, karena iframe butuh URL spesifik, kita gunakan tampilan visual map. Jika Anda punya URL embed Maps, bisa ganti iframe-nya. */}
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d126907.08630712391!2d106.772583!3d-6.600989!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69c5c24e8e7a0f%3A0x301576d14feb9b0!2sBogor%2C%20Bogor%20City%2C%20West%20Java!5e0!3m2!1sen!2sid!4v1689000000000!5m2!1sen!2sid"
                width="100%"
                height="100%"
                style={{ border: 0, minHeight: "400px" }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                className="absolute inset-0"
              ></iframe>
            </div>
          </div>
        </section>

        {/* Struktur Organisasi RW (Bagan) */}
        <section>
          <div className="flex items-center gap-3 mb-10">
            <div className="w-1 h-8 bg-primary rounded-full" />
            <h2 className="text-2xl font-black text-foreground uppercase tracking-tight" style={{ fontFamily: "var(--font-bitter)" }}>
              Struktur Pengurus Harian RW 10
            </h2>
          </div>

          <div className="bg-card border border-border/60 rounded-3xl p-8 shadow-sm overflow-x-auto">
            <div className="min-w-[600px] flex flex-col items-center justify-center pb-8 pt-4">
              
              {/* Ketua RW */}
              <div className="flex flex-col items-center group cursor-default">
                <div className={`w-20 h-20 rounded-2xl bg-gradient-to-br ${pengurusHarian.ketua.color} flex items-center justify-center shadow-lg ring-4 ring-white z-10 relative group-hover:scale-105 transition-transform`}>
                  <Users className="w-10 h-10 text-white" />
                </div>
                <div className="bg-white border shadow-sm rounded-xl px-6 py-4 mt-[-10px] text-center w-64 pt-6">
                  <span className={`inline-block text-[10px] font-black px-2.5 py-1 rounded-full uppercase tracking-wider mb-2 ${pengurusHarian.ketua.badgeColor}`}>
                    {pengurusHarian.ketua.jabatan}
                  </span>
                  <h3 className="font-black text-foreground">{pengurusHarian.ketua.nama}</h3>
                  <p className="text-xs text-muted-foreground mt-1 flex items-center justify-center gap-1">
                    <Phone className="w-3 h-3" /> {pengurusHarian.ketua.no_hp}
                  </p>
                </div>
              </div>

              {/* Garis Vertikal */}
              <div className="w-0.5 h-12 bg-border relative">
                {/* Garis Horizontal ke Sekretaris & Bendahara */}
                <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[400px] h-0.5 bg-border"></div>
              </div>

              {/* Cabang Sekretaris & Bendahara */}
              <div className="flex justify-between w-[400px] relative mt-0">
                {/* Garis Turun ke Sekretaris */}
                <div className="w-0.5 h-6 bg-border absolute left-0 top-0"></div>
                {/* Garis Turun ke Bendahara */}
                <div className="w-0.5 h-6 bg-border absolute right-0 top-0"></div>

                {/* Sekretaris RW */}
                <div className="flex flex-col items-center absolute -left-[100px] top-6 group cursor-default">
                  <div className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${pengurusHarian.sekretaris.color} flex items-center justify-center shadow-lg ring-4 ring-white z-10 relative group-hover:scale-105 transition-transform`}>
                    <Users className="w-8 h-8 text-white" />
                  </div>
                  <div className="bg-white border shadow-sm rounded-xl px-4 py-3 mt-[-10px] text-center w-52 pt-5">
                    <span className={`inline-block text-[10px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider mb-1.5 ${pengurusHarian.sekretaris.badgeColor}`}>
                      {pengurusHarian.sekretaris.jabatan}
                    </span>
                    <h3 className="font-bold text-sm text-foreground leading-tight">{pengurusHarian.sekretaris.nama}</h3>
                  </div>
                </div>

                {/* Bendahara RW */}
                <div className="flex flex-col items-center absolute -right-[100px] top-6 group cursor-default">
                  <div className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${pengurusHarian.bendahara.color} flex items-center justify-center shadow-lg ring-4 ring-white z-10 relative group-hover:scale-105 transition-transform`}>
                    <Users className="w-8 h-8 text-white" />
                  </div>
                  <div className="bg-white border shadow-sm rounded-xl px-4 py-3 mt-[-10px] text-center w-52 pt-5">
                    <span className={`inline-block text-[10px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider mb-1.5 ${pengurusHarian.bendahara.badgeColor}`}>
                      {pengurusHarian.bendahara.jabatan}
                    </span>
                    <h3 className="font-bold text-sm text-foreground leading-tight">{pengurusHarian.bendahara.nama}</h3>
                  </div>
                </div>

              </div>
              
              {/* Spacing for absolute positioned elements */}
              <div className="h-40"></div>

            </div>
          </div>
        </section>

        {/* RT & Lembaga (Link Dinamis) */}
        <section>
          <div className="flex items-center gap-3 mb-8">
            <div className="w-1 h-8 bg-primary rounded-full" />
            <h2 className="text-2xl font-black text-foreground uppercase tracking-tight" style={{ fontFamily: "var(--font-bitter)" }}>
              Daftar RT & Lembaga
            </h2>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {lembagaList.map((lembaga) => (
              <Link 
                key={lembaga.slug} 
                href={`/lembaga/${lembaga.slug}`}
                className={`flex flex-col items-center justify-center p-6 rounded-2xl border transition-all duration-300 group shadow-sm ${lembaga.color}`}
              >
                <lembaga.icon className="w-10 h-10 mb-3" />
                <span className="font-bold text-base text-center line-clamp-1">{lembaga.name}</span>
                <span className="text-xs opacity-80 mt-1 flex items-center gap-1 group-hover:underline">
                  Lihat Profil <ChevronRight className="w-3 h-3" />
                </span>
              </Link>
            ))}
          </div>
        </section>


        {/* Visi & Misi */}
        <section>
          <div className="flex items-center gap-3 mb-8">
            <div className="w-1 h-8 bg-primary rounded-full" />
            <h2 className="text-2xl font-black text-foreground uppercase tracking-tight" style={{ fontFamily: "var(--font-bitter)" }}>
              Visi & Misi
            </h2>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-gradient-to-br from-[#1a56db] to-[#0f172a] rounded-3xl p-8 text-white relative overflow-hidden">
              <div className="absolute -top-8 -right-8 w-32 h-32 bg-white/5 rounded-full" />
              <div className="relative z-10">
                <div className="flex items-center gap-3 mb-4">
                  <div className="bg-amber-400 p-2.5 rounded-xl">
                    <Eye className="w-5 h-5 text-[#0f172a]" />
                  </div>
                  <h3 className="text-xl font-black uppercase tracking-wide">Visi</h3>
                </div>
                <p className="text-blue-100 leading-relaxed font-medium text-base">
                  &ldquo;{visiMisi.visi}&rdquo;
                </p>
              </div>
            </div>

            <div className="bg-card border border-border/60 rounded-3xl p-8 shadow-sm">
              <div className="flex items-center gap-3 mb-5">
                <div className="bg-amber-100 p-2.5 rounded-xl">
                  <Target className="w-5 h-5 text-amber-600" />
                </div>
                <h3 className="text-xl font-black text-foreground uppercase tracking-wide">Misi</h3>
              </div>
              <ul className="space-y-3">
                {visiMisi.misi.map((m, i) => (
                  <li key={i} className="flex items-start gap-3 text-sm text-muted-foreground leading-relaxed">
                    <span className="flex-shrink-0 w-6 h-6 bg-primary/10 text-primary text-xs font-black rounded-full flex items-center justify-center mt-0.5">
                      {i + 1}
                    </span>
                    {m}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </section>

      </div>
    </div>
  );
}
