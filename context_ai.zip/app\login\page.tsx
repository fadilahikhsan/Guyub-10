"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import {
  MountainIcon,
  ArrowLeft,
  Loader2,
  Eye,
  EyeOff,
  IdCard,
  User,
  MapPin,
  Mail,
  Lock,
  CheckCircle,
} from "lucide-react";
import { login, signup } from "./actions";

interface InputFieldProps {
  id: string;
  name: string;
  type: string;
  label: string;
  placeholder: string;
  required?: boolean;
  maxLength?: number;
  pattern?: string;
  icon: React.ElementType;
  hint?: string;
}

function InputField({
  id, name, type, label, placeholder, required, maxLength, pattern, icon: Icon, hint,
}: InputFieldProps) {
  const [showPassword, setShowPassword] = useState(false);
  const isPassword = type === "password";
  const inputType = isPassword ? (showPassword ? "text" : "password") : type;

  return (
    <div className="space-y-1.5">
      <label className="text-sm font-bold leading-none text-foreground" htmlFor={id}>
        {label}
      </label>
      <div className="relative">
        <Icon className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none" />
        <input
          id={id}
          name={name}
          type={inputType}
          placeholder={placeholder}
          required={required}
          maxLength={maxLength}
          pattern={pattern}
          className="flex h-12 w-full rounded-xl border-2 border-border bg-muted/40 pl-11 pr-11 text-sm focus-visible:outline-none focus-visible:border-primary focus-visible:bg-white focus-visible:ring-4 focus-visible:ring-primary/10 transition-all font-medium placeholder:text-muted-foreground/60"
        />
        {isPassword && (
          <button
            type="button"
            onClick={() => setShowPassword((v) => !v)}
            className="absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
            tabIndex={-1}
            aria-label={showPassword ? "Sembunyikan kata sandi" : "Tampilkan kata sandi"}
          >
            {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
          </button>
        )}
      </div>
      {hint && <p className="text-xs text-muted-foreground pl-1">{hint}</p>}
    </div>
  );
}

export default function LoginPage() {
  const [isRegister, setIsRegister] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");
  const [successMessage, setSuccessMessage] = useState("");

  useEffect(() => {
    const searchParams = new URLSearchParams(window.location.search);
    if (searchParams.get("mode") === "register") {
      setTimeout(() => setIsRegister(true), 0);
    }
    if (searchParams.get("registered") === "1") {
      setTimeout(() => setSuccessMessage("Akun berhasil dibuat! Silakan login."), 0);
    }
  }, []);

  const handleSubmit = async (formData: FormData) => {
    setIsLoading(true);
    setErrorMessage("");
    setSuccessMessage("");

    let result;
    if (isRegister) {
      result = await signup(formData);
    } else {
      result = await login(formData);
    }

    if (result?.error) {
      setErrorMessage(result.error);
      setIsLoading(false);
    }
  };

  const switchMode = () => {
    setIsRegister((v) => !v);
    setErrorMessage("");
    setSuccessMessage("");
  };

  return (
    <div className="min-h-screen flex items-center justify-center relative overflow-hidden bg-gradient-to-br from-slate-50 via-blue-50/30 to-slate-100 p-4">
      {/* Decorative background blobs */}
      <div className="absolute inset-0 -z-10 overflow-hidden">
        <div className="absolute top-1/4 left-1/4 h-72 w-72 -translate-x-1/2 -translate-y-1/2 rounded-full bg-primary/8 blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 h-96 w-96 translate-x-1/2 translate-y-1/2 rounded-full bg-blue-400/8 blur-3xl" />
        <div className="absolute top-3/4 left-1/2 h-48 w-48 rounded-full bg-amber-400/6 blur-2xl" />
      </div>

      {/* Back to home */}
      <Link
        href="/"
        className="absolute top-6 left-6 flex items-center gap-2 text-sm font-semibold text-muted-foreground hover:text-foreground transition-colors group"
      >
        <ArrowLeft className="h-4 w-4 transition-transform group-hover:-translate-x-1" />
        Kembali ke Beranda
      </Link>

      <div className="w-full max-w-md relative z-10">
        {/* Logo & Header */}
        <div className="flex flex-col items-center mb-8">
          <Link href="/" className="flex items-center gap-2.5 mb-5 group">
            <div className="bg-primary p-3 rounded-2xl shadow-lg shadow-primary/20 group-hover:bg-primary/90 transition-colors">
              <MountainIcon className="h-7 w-7 text-white" />
            </div>
            <span
              className="text-3xl font-black tracking-tight text-foreground"
              style={{ fontFamily: "var(--font-bitter)" }}
            >
              Guyub<span className="text-primary">.</span>
            </span>
          </Link>
          <h1 className="text-2xl font-black tracking-tight text-foreground">
            {isRegister ? "Daftar Akun Warga" : "Selamat Datang Kembali"}
          </h1>
          <p className="text-muted-foreground mt-1.5 text-center text-sm font-medium max-w-xs">
            {isRegister
              ? "Isi data diri Anda untuk bergabung dengan Portal Guyub RW 10"
              : "Masukkan email dan kata sandi untuk mengakses layanan"}
          </p>
        </div>

        {/* Card */}
        <div className="bg-white border border-border/60 rounded-2xl p-7 shadow-xl shadow-slate-200/60">
          {/* Success Message */}
          {successMessage && (
            <div className="mb-5 p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-700 text-sm font-semibold flex items-center gap-2">
              <CheckCircle className="w-4 h-4 flex-shrink-0" />
              {successMessage}
            </div>
          )}

          {/* Error Message */}
          {errorMessage && (
            <div className="mb-5 p-3.5 rounded-xl bg-red-50 border border-red-200 text-destructive text-sm font-semibold">
              ⚠️ {errorMessage}
            </div>
          )}

          <form action={handleSubmit} className="space-y-4">
            {/* === Register-only fields === */}
            {isRegister && (
              <>
                <InputField
                  id="nik"
                  name="nik"
                  type="text"
                  label="NIK (Nomor Induk Kependudukan)"
                  placeholder="16 digit angka NIK Anda"
                  required
                  maxLength={16}
                  pattern="\d{16}"
                  icon={IdCard}
                  hint="Sesuai KTP — 16 digit angka"
                />
                <InputField
                  id="nama_lengkap"
                  name="nama_lengkap"
                  type="text"
                  label="Nama Lengkap"
                  placeholder="Sesuai KTP"
                  required
                  icon={User}
                />
                <div className="space-y-1.5">
                  <label className="text-sm font-bold leading-none text-foreground" htmlFor="rt">
                    Nomor RT
                  </label>
                  <div className="relative">
                    <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none" />
                    <select
                      id="rt"
                      name="rt"
                      required
                      defaultValue=""
                      className="flex h-12 w-full rounded-xl border-2 border-border bg-muted/40 pl-11 pr-4 text-sm focus-visible:outline-none focus:border-primary focus:ring-4 focus:ring-primary/10 transition-all font-medium appearance-none cursor-pointer"
                    >
                      <option value="" disabled>Pilih RT Anda...</option>
                      {[1, 2, 3, 4, 5, 6, 7, 8].map((n) => (
                        <option key={n} value={n.toString()}>
                          RT {String(n).padStart(2, "0")} — RW 10
                        </option>
                      ))}
                    </select>
                  </div>
                  <p className="text-xs text-muted-foreground pl-1">Lingkungan RW 10 Desa Cicadas</p>
                </div>
                <div className="border-t border-border/50 pt-1" />
              </>
            )}

            {/* === Common fields === */}
            <InputField
              id="email"
              name="email"
              type="email"
              label="Alamat Email"
              placeholder="nama@email.com"
              required
              icon={Mail}
            />
            <InputField
              id="password"
              name="password"
              type="password"
              label="Kata Sandi"
              placeholder={isRegister ? "Minimal 8 karakter" : "Masukkan kata sandi"}
              required
              icon={Lock}
              hint={isRegister ? "Gunakan kombinasi huruf, angka, dan simbol" : undefined}
            />

            {/* Forgot password */}
            {!isRegister && (
              <div className="flex justify-end -mt-2">
                <a href="#" className="text-xs font-bold text-primary hover:underline underline-offset-4">
                  Lupa kata sandi?
                </a>
              </div>
            )}

            {/* Submit */}
            <button
              type="submit"
              disabled={isLoading}
              className="inline-flex h-12 w-full items-center justify-center rounded-xl bg-primary text-white text-sm font-bold shadow-lg shadow-primary/25 hover:-translate-y-0.5 hover:shadow-xl hover:shadow-primary/30 transition-all disabled:pointer-events-none disabled:opacity-70 mt-2"
            >
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  {isRegister ? "Mendaftarkan..." : "Masuk..."}
                </>
              ) : isRegister ? (
                "Daftar Sekarang →"
              ) : (
                "Masuk ke Sistem →"
              )}
            </button>
          </form>

          {/* Divider */}
          <div className="mt-6 relative">
            <div className="absolute inset-0 flex items-center">
              <span className="w-full border-t border-border" />
            </div>
            <div className="relative flex justify-center text-xs uppercase font-bold">
              <span className="bg-white px-3 text-muted-foreground">atau</span>
            </div>
          </div>

          {/* Switch mode */}
          <p className="text-center text-sm text-muted-foreground mt-5 font-medium">
            {isRegister ? "Sudah punya akun? " : "Belum punya akun? "}
            <button
              onClick={switchMode}
              className="font-bold text-primary hover:underline underline-offset-4 transition-colors"
            >
              {isRegister ? "Masuk di sini" : "Daftar sebagai warga"}
            </button>
          </p>
        </div>

        {/* Info box — only on register */}
        {isRegister && (
          <div className="mt-4 p-4 bg-blue-50 border border-blue-200 rounded-xl text-xs text-blue-700 font-medium">
            <p className="font-bold mb-1">ℹ️ Informasi Pendaftaran</p>
            <p>
              Data Anda (NIK & nama) digunakan untuk verifikasi kependudukan oleh
              Pengurus RW 10. Data tidak akan dibagikan ke pihak ketiga.
            </p>
          </div>
        )}

        <p className="text-center text-xs text-muted-foreground mt-6 font-medium">
          © {new Date().getFullYear()} Portal Digital RW 10 Desa Cicadas
        </p>
      </div>
    </div>
  );
}
