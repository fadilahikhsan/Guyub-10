import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import { FileText, Users, Store, Megaphone, Calendar } from "lucide-react";
import { SuratTable } from "./SuratTable";
import { PengumumanManager } from "./PengumumanManager";
import KegiatanManager from "./KegiatanManager";
import { UmkmManager } from "./UmkmManager";

export const revalidate = 0;

export default async function AdminDashboardPage() {
  const supabase = await createClient();

  const { data: { user } } = await supabase.auth.getUser();
  // BYPASS: if (!user) redirect("/login");

  // Ambil data statistik dan list
  const [
    { count: countProfiles },
    { count: countSurat },
    { count: countUmkm },
    { count: countPengumuman },
    { count: countKegiatan },
    { data: suratList },
    { data: pengumumanList },
    { data: kegiatanList },
    { data: umkmListAdmin },
  ] = await Promise.all([
    supabase.from("profiles").select("*", { count: "exact", head: true }),
    supabase.from("surat").select("*", { count: "exact", head: true }).eq("status", "pending"),
    supabase.from("umkm").select("*", { count: "exact", head: true }),
    supabase.from("pengumuman").select("*", { count: "exact", head: true }),
    supabase.from("kegiatan").select("*", { count: "exact", head: true }),
    supabase.from("surat").select(`id, jenis_surat, keperluan, status, catatan_admin, lampiran_url, created_at, profiles ( nama_lengkap, rt )`).order("created_at", { ascending: false }).limit(50),
    supabase.from("pengumuman").select("id, judul, konten, kategori, created_at").order("created_at", { ascending: false }),
    supabase.from("kegiatan").select("*").order("tanggal", { ascending: true }),
    supabase.from("umkm").select(`id, nama_usaha, kategori, deskripsi, nomor_wa, is_approved, created_at, profiles ( nama_lengkap, rt )`).order("created_at", { ascending: false }),
  ]);

  const stats = [
    { icon: Users, label: "Total Warga", value: countProfiles ?? 0, unit: "terdaftar", color: "blue" },
    { icon: FileText, label: "Surat Pending", value: countSurat ?? 0, unit: "menunggu", color: "amber" },
    { icon: Store, label: "UMKM", value: countUmkm ?? 0, unit: "usaha", color: "emerald" },
    { icon: Megaphone, label: "Pengumuman", value: countPengumuman ?? 0, unit: "postingan", color: "purple" },
  ];

  const colorMap: Record<string, { bg: string; text: string; icon: string }> = {
    blue: { bg: "bg-blue-50", text: "text-blue-600", icon: "bg-blue-100 text-blue-600" },
    amber: { bg: "bg-amber-50", text: "text-amber-600", icon: "bg-amber-100 text-amber-600" },
    emerald: { bg: "bg-emerald-50", text: "text-emerald-600", icon: "bg-emerald-100 text-emerald-600" },
    purple: { bg: "bg-purple-50", text: "text-purple-600", icon: "bg-purple-100 text-purple-600" },
  };

  return (
    <div className="space-y-8 text-zinc-900">
      {/* Header */}
      <div>
        <h2 className="text-3xl font-black mb-1">Dashboard Pengurus RW</h2>
        <p className="text-zinc-500 font-medium">Berikut adalah ringkasan data dan aktivitas terbaru Portal Guyub RW 10.</p>
      </div>

      {/* Stat Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
        {stats.map((stat) => {
          const c = colorMap[stat.color];
          return (
            <div key={stat.label} className={`${c.bg} p-6 rounded-3xl border border-zinc-200/60 shadow-sm hover:shadow-md transition-shadow`}>
              <div className="flex items-center gap-3 mb-4">
                <div className={`${c.icon} p-3 rounded-xl`}>
                  <stat.icon className="w-6 h-6" />
                </div>
                <h3 className="text-base font-bold text-zinc-700">{stat.label}</h3>
              </div>
              <p className={`text-4xl font-black ${c.text}`}>
                {stat.value}
                <span className="text-sm text-zinc-400 font-medium ml-2">{stat.unit}</span>
              </p>
            </div>
          );
        })}
      </div>

      {/* Surat Section */}
      <div className="bg-white p-6 md:p-8 rounded-3xl border-2 border-zinc-200 shadow-sm">
        <div className="flex items-center gap-2 mb-6">
          <FileText className="w-5 h-5 text-emerald-500" />
          <h3 className="text-xl font-black text-zinc-800">Manajemen Pengajuan Surat</h3>
        </div>
        <SuratTable suratList={suratList ?? []} />
      </div>

      {/* UMKM Section */}
      <UmkmManager umkmList={umkmListAdmin ?? []} />

      {/* Kegiatan Section */}
      <KegiatanManager data={kegiatanList ?? []} />

      {/* Pengumuman Section */}
      <PengumumanManager pengumumanList={pengumumanList ?? []} />
    </div>
  );
}
