import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { ChevronRight, Calendar, MapPin, Clock, Info } from "lucide-react";

export const revalidate = 0; // Dynamic route

export default async function KegiatanPage() {
  const supabase = await createClient();

  // Ambil data kegiatan dari database, urutkan berdasarkan tanggal terdekat yang akan datang
  const { data: kegiatanData } = await supabase
    .from("kegiatan")
    .select("*")
    .gte("tanggal", new Date().toISOString()) // Hanya ambil yang belum lewat atau hari ini
    .order("tanggal", { ascending: true });

  const kegiatan = kegiatanData || [];

  // Helper untuk format tanggal & waktu
  const formatTanggal = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString("id-ID", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  };

  const formatWaktu = (dateStr: string) => {
    return new Date(dateStr).toLocaleTimeString("id-ID", {
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  // Kategori colors
  const getCategoryColor = (kategori: string) => {
    switch (kategori) {
      case "Pengajian":
        return "bg-emerald-100 text-emerald-700 border-emerald-200";
      case "Kerja Bakti":
        return "bg-amber-100 text-amber-700 border-amber-200";
      case "Posyandu":
        return "bg-rose-100 text-rose-700 border-rose-200";
      case "Karang Taruna":
        return "bg-indigo-100 text-indigo-700 border-indigo-200";
      case "Rapat":
        return "bg-slate-100 text-slate-700 border-slate-200";
      default:
        return "bg-blue-100 text-blue-700 border-blue-200";
    }
  };

  return (
    <div className="flex flex-col min-h-screen bg-background">
      {/* Hero Banner */}
      <section className="relative overflow-hidden bg-gradient-to-br from-primary via-blue-700 to-secondary geo-pattern">
        <div className="absolute top-8 right-8 w-48 h-48 border border-white/10 rounded-full" />
        <div className="absolute -bottom-12 -left-12 w-64 h-64 bg-white/5 rounded-full blur-3xl" />

        <div className="container mx-auto px-4 max-w-6xl py-12 md:py-16 relative z-10">
          <div className="flex items-center text-sm font-bold text-blue-200 mb-6">
            <Link href="/" className="hover:text-white transition-colors">Beranda</Link>
            <ChevronRight className="h-4 w-4 mx-2" />
            <span className="text-white">Agenda Kegiatan</span>
          </div>

          <h1
            className="text-3xl md:text-5xl font-black text-white leading-tight mb-3"
            style={{ fontFamily: "var(--font-bitter)" }}
          >
            Agenda Kegiatan Warga
          </h1>
          <p className="text-blue-100 text-lg font-medium max-w-2xl">
            Pantau jadwal kegiatan rutin dan insidental di lingkungan RW 10 Desa Cicadas. Mari bersama-sama berpartisipasi untuk lingkungan yang lebih baik.
          </p>
        </div>
      </section>

      {/* Main Content */}
      <div className="container mx-auto px-4 max-w-6xl py-12 space-y-12">
        <div className="flex flex-col md:flex-row gap-8">
          
          {/* List Kegiatan (Kiri) */}
          <div className="flex-1 space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-black text-foreground" style={{ fontFamily: "var(--font-bitter)" }}>
                Kegiatan Mendatang
              </h2>
            </div>

            {kegiatan.length === 0 ? (
              <div className="bg-card border border-border rounded-2xl p-8 text-center shadow-sm">
                <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
                  <Calendar className="w-8 h-8 text-muted-foreground" />
                </div>
                <h3 className="font-bold text-lg mb-1">Belum Ada Kegiatan</h3>
                <p className="text-sm text-muted-foreground">Saat ini tidak ada jadwal kegiatan mendatang yang tercatat.</p>
              </div>
            ) : (
              <div className="space-y-4">
                {kegiatan.map((item) => (
                  <div key={item.id} className="bg-card border border-border/60 hover:border-primary/50 transition-colors rounded-2xl p-5 shadow-sm card-hover flex flex-col sm:flex-row gap-5">
                    
                    {/* Date Block */}
                    <div className="flex-shrink-0 flex flex-col items-center justify-center bg-muted/50 rounded-xl px-4 py-3 min-w-[100px] text-center border border-border">
                      <span className="text-xs font-bold text-muted-foreground uppercase mb-1">
                        {new Date(item.tanggal).toLocaleDateString("id-ID", { month: "short" })}
                      </span>
                      <span className="text-3xl font-black text-primary leading-none">
                        {new Date(item.tanggal).getDate()}
                      </span>
                      <span className="text-xs font-semibold text-muted-foreground mt-1">
                        {new Date(item.tanggal).toLocaleDateString("id-ID", { weekday: "short" })}
                      </span>
                    </div>

                    {/* Info */}
                    <div className="flex-1 min-w-0">
                      <span className={`inline-block text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full border mb-2 ${getCategoryColor(item.kategori)}`}>
                        {item.kategori}
                      </span>
                      <h3 className="text-lg font-bold text-foreground leading-tight mb-2">
                        {item.judul}
                      </h3>
                      {item.deskripsi && (
                        <p className="text-sm text-muted-foreground line-clamp-2 mb-3">
                          {item.deskripsi}
                        </p>
                      )}
                      
                      <div className="flex flex-wrap items-center gap-3 mt-auto">
                        <div className="flex items-center text-xs font-medium text-slate-500">
                          <Clock className="w-3.5 h-3.5 mr-1 text-slate-400" />
                          {formatWaktu(item.tanggal)} WIB
                        </div>
                        <div className="flex items-center text-xs font-medium text-slate-500">
                          <MapPin className="w-3.5 h-3.5 mr-1 text-slate-400" />
                          {item.lokasi}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Sidebar Kalender Mini (Kanan) */}
          <div className="w-full md:w-[320px] flex-shrink-0 space-y-6">
            <div className="bg-card border border-border rounded-2xl p-5 shadow-sm">
              <h3 className="font-black text-lg border-b pb-3 mb-4" style={{ fontFamily: "var(--font-bitter)" }}>
                Info Penting
              </h3>
              <div className="flex items-start gap-3 text-sm text-muted-foreground bg-amber-50 p-3 rounded-xl border border-amber-200/50">
                <Info className="w-5 h-5 text-amber-500 flex-shrink-0 mt-0.5" />
                <p>Seluruh warga diharapkan partisipasi aktifnya dalam setiap kegiatan lingkungan untuk mewujudkan RW yang Guyub dan Rukun.</p>
              </div>
            </div>

            {/* Ilustrasi atau Call to Action */}
            <div className="bg-gradient-to-br from-primary to-navy rounded-2xl p-6 text-white text-center relative overflow-hidden shadow-lg">
              <div className="absolute top-0 right-0 w-32 h-32 bg-white/5 rounded-full blur-xl" />
              <div className="relative z-10">
                <Calendar className="w-10 h-10 text-blue-200 mx-auto mb-3" />
                <h3 className="font-bold text-lg mb-2">Punya Usulan Kegiatan?</h3>
                <p className="text-xs text-blue-100/80 mb-4 line-clamp-2">Sampaikan ke pengurus RT masing-masing untuk diagendakan di tingkat RW.</p>
                <Link href="/profil" className="inline-block bg-white text-primary text-xs font-bold px-4 py-2 rounded-lg hover:bg-blue-50 transition-colors">
                  Hubungi Pengurus
                </Link>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}
